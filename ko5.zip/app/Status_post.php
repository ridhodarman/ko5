<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Status_post extends Model
{
    protected $fillable = ['nama'];
}
