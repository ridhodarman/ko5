<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fasilitas_post extends Model
{
    protected $fillable = ['nama'];
}
