<?php $__env->startSection('isi'); ?>
<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h4 class="font-weight-bold mb-0"> </h4>
            </div>
            <div>
                <a href="<?php echo e(route('pemilik')); ?>">
                    <button type="button" class="btn btn-outline-info btn-fw">
                        <i class=" ti-angle-double-left "></i> Kembali ke daftar pemilik
                    </button>
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $pemilik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p class="card-title text-md-center text-xl-left" style="color: black; font-weight: bolder;">
                            Informasi Pemilik</p>
                        <table class="table table-hover">
                            <?php $__currentLoopData = $pemilik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Nama Pemilik</td>
                                <td>:</td>
                                <td><?php echo e($k->nama); ?></td>
                            </tr>
                            <tr>
                                <td>Kontak</td>
                                <td>:</td>
                                <td><?php echo e($k->kontak); ?></td>
                            </tr>
                            <tr>
                                <td>Deskripsi</td>
                                <td>:</td>
                                <td><?php echo e($k->deskripsi); ?></td>
                            </tr>
                            <tr>
                                <td>Dibuat Pada</td>
                                <td>:</td>
                                <td><?php echo e($k->created_at); ?></td>
                            </tr>
                            <tr>
                                <td>Terakhir diubah</td>
                                <td>:</td>
                                <td><?php echo e($k->updated_at); ?></td>
                            </tr>
                            <tr>
                                <td>Akun</td>
                                <td>:</td>
                                <td>
                                    <a href="#"><?php echo e($k->email); ?></a>&emsp;
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>Post</td>
                                <td>:</td>
                                <td>
                                    <?php $__currentLoopData = $pemilik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('post')); ?>/<?php echo e($k->post_id); ?>"><?php echo e($k->post); ?></a>&emsp;
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form action="<?php echo e(route('pemilik')); ?>/<?php echo e($k->id); ?>" method="POST" class="d-inline">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
    <button type="button" class="btn btn-outline-danger btn-fw" id="tombol-hapus">
        <i class="ti-trash"></i> Hapus
    </button>
</form>

<script>
    let peringatan=true;
    $('#tombol-hapus').on('click', function (e) {
        if(peringatan==true){
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this data!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
                .then((willDelete) => {
                    if (willDelete) {
                        peringatan = false;
                        $('#tombol-hapus').removeAttr("type").attr("type", "submit");
                        $('#tombol-hapus').trigger( "click" );
                    }
                });
        }
    });
</script>

<a href="<?php echo e(route('pemilik')); ?>/<?php echo e($k->id); ?>/edit">
    <button type="button" class="btn btn-outline-warning btn-fw">
        <i class="ti-edit"></i> Edit
    </button>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script type="text/javascript">

    $(document).ready(function () {
        $('#example').DataTable();
        $("#post2").css("color", "black");
        $( "#kelola" ).addClass( "active" );
        $( "#pemilik_post" ).css("color", "black");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ko5\resources\views/admin/pemilik/view.blade.php ENDPATH**/ ?>