<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body" style="text-align: center;">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    Welcome <b><?php echo Auth::user()->name ?></b> !
                    <br/>
                    
                    <img src="<?php echo e(route('foto')); ?>/dll/profile.png" width="100px">
                    <a href="#">
                        <button type="button" class="btn btn-outline-secondary btn-sm">Edit Profil</button>
                    </a>
                    <br/>
                    <?php if(Auth::check() &&Auth::user()->role == 99 ): ?> 
                    <a href="<?php echo e(route('post')); ?>">
                        <button class="btn btn-success mt-2 mb-2"><i class="fa fa-search"></i> Pergi ke halaman admin</button>
                    </a>
                    <br/>
                    <?php endif; ?>
                    <a href="<?php echo e(route('cari')); ?>">
                        <button class="btn btn-primary mt-2"><i class="fa fa-search"></i> Cari Kos / kontrakan</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ko5\resources\views/home.blade.php ENDPATH**/ ?>