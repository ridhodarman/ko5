

<?php $__env->startSection('title', 'Cari Kos'); ?>

<?php $__env->startSection('judul'); ?>
<nav>
    <ol class="breadcrumb text-white">
        <li class="breadcrumb-item"><a href="#">Home</a></li>
        <li class="breadcrumb-item"><a href='<?php echo e(route("cari")); ?>'>Cari Kos</a></li>
    </ol>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('isi'); ?>

            <div class="row">
                <aside id="sidebar" class="col-md-3"></aside><!-- col.// -->
                <script>
                    $('#sidebar').load(`<?php echo e(route('sidebar')); ?>`);
                </script>
                <main class="col-md-9">

                    <header class="border-bottom mb-4 pb-3">
                        <div class="form-inline">
                            <span class="mr-md-auto">
                                <span id="jumlah"> <?php echo e($post->total()); ?> </span>
                                <span style="color: darkgray;"> Items found </span>
                                <?php if(isset($filter)): ?>
                                |Filter: 
                                <?php echo $filter; ?>

                                <a href="<?php echo e(route('cari')); ?>">
                                    <span class="badge badge-danger glow">
                                        <i class="fas fa-times-circle"></i> Clear all filters
                                    </span>
                                </a>
                                <?php endif; ?>
                            </span>
                        </div>
                    </header><!-- sect-heading -->

                    <div class="row">

                        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="col-md-4">
                            <figure class="card card-product-grid" style="height: 95%;">
                                <div class="img-wrap">
                                    <?php
                                        if($p->cover){
                                            $gambar = 'foto/'.$p->cover;
                                        }
                                        else {
                                            $gambar = "null.png";
                                        }
                                    ?>
                                    <a href="<?php echo e(route('info')); ?>/<?php echo e($p->id); ?>" target="_blank"><img src="<?php echo e(URL::asset($gambar)); ?>"></a>
                                    <a class="btn-overlay" href="javascript:;" data-toggle="modal" data-target="#exampleModal<?php echo e($p->id); ?>"><i class="fa fa-search-plus"></i> Quick View</a>
                                    <div class="modal fade" id="exampleModal<?php echo e($p->id); ?>" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($p->nama); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <a href="<?php echo e(route('info')); ?>/<?php echo e($p->id); ?>" target="_blank">
                                                        <img src="<?php echo e(URL::asset($gambar)); ?>">
                                                    </a>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal">Close</button>
                                                    <a href="<?php echo e(route('info')); ?>/<?php echo e($p->id); ?>" target="_blank">
                                                        <button type="button" class="btn btn-primary">Lihat Tempat</button>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- img-wrap.// -->
                                <figcaption class="info-wrap">
                                    <!-- <div class="fix-height"> -->
                                    <div>
                                        <a href="<?php echo e(route('info')); ?>/<?php echo e($p->id); ?>" class="title">
                                            <div style="font-weight: bolder;"><?php echo e($p->nama); ?></div>
                                            <div style="font-size: 85%; color: rgb(46, 46, 46);">
                                                <span class='badge badge-pill badge-light'><?php echo e($p->jenis); ?></span>
                                                <?php if(isset($p->jarak)): ?>
                                                Sekitar <?php echo e(str_replace (".", ",", round($p->jarak, 2) )); ?> Kilometer dari pusat <?php echo e($lokasi); ?>

                                                <?php endif; ?>
                                            </div>
                                        </a>
                                        <div class="price-wrap mt-1 mb-1">
                                            <span class="price" style="color: green;">
                                                Rp. <?php echo e(str_replace (",", ".", number_format($p->harga) )); ?> / <?php echo e($p->pembayaran); ?>

                                            </span>
                                        </div> <!-- price-wrap.// -->
                                    </div>
                                    <a href="<?php echo e(route('info')); ?>/<?php echo e($p->id); ?>" target="_blank" class="btn btn-block btn-primary">Lihat Tempat</a>
                                </figcaption>
                            </figure>
                        </div> <!-- col.// -->
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div> <!-- row end.// -->


                    <nav class="mt-4" aria-label="Page navigation sample">
                        <ul class="pagination">
                            <?php echo e($post->links()); ?>

                        </ul>
                    </nav>

                    <!-- <nav class="mt-4" aria-label="Page navigation sample">
                        <ul class="pagination">
                            <li class="page-item disabled"><a class="page-link" href="#">Previous</a></li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                        </ul>
                    </nav> -->

                </main> <!-- col.// -->

            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cari.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ko5\resources\views/cari/index.blade.php ENDPATH**/ ?>