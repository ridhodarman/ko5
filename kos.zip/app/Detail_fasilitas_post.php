<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detail_fasilitas_post extends Model
{
    protected $fillable = ['post_id', 'fasilitas_posts'];
}
