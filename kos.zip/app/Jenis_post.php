<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jenis_post extends Model
{
    protected $fillable = ['nama'];
}
