<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body" style="text-align: center;">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                    <br/>
                    <a href="#">
                        <button class="btn btn-block btn-primary mt-5"><i class="fa fa-search"></i> Ubah profil</button>
                    </a>

                    <?php if(Auth::check() &&Auth::user()->role == 99 ): ?> 
                    <a href="<?php echo e(route('post')); ?>">
                        <button class="btn btn-block btn-primary mt-5"><i class="fa fa-search"></i> Pergi ke halaman admin</button>
                    </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('cari')); ?>">
                        <button class="btn btn-block btn-primary mt-5"><i class="fa fa-search"></i> Pergi ke halaman user</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ko5\resources\views/home.blade.php ENDPATH**/ ?>