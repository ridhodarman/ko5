 <!-- ========================= FOOTER ========================= -->
 <footer class="section-footer border-top padding-y">
    <div class="container">
        <p class="float-md-right">
            &copy Copyright 2020 Some rights reserved
        </p>
        <p>
            <a href="#">Terms and conditions</a>
        </p>
    </div><!-- //container -->
</footer>
<!-- ========================= FOOTER END // ========================= --><?php /**PATH E:\xampp\htdocs\ko5\resources\views/cari/inc/footer.blade.php ENDPATH**/ ?>